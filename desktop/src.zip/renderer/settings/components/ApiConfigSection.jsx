import React, { useState, useEffect } from 'react'

const EMPTY_FORM = {
  name: '',
  base_url: '',
  api_key: '',
  model: '',
  system_prompt: '',
}

const PRESETS = [
  { label: 'DeepSeek', base_url: 'https://api.deepseek.com', model: 'deepseek-chat' },
  { label: 'OpenAI', base_url: 'https://api.openai.com', model: 'gpt-4o-mini' },
  { label: 'Moonshot (Kimi)', base_url: 'https://api.moonshot.cn', model: 'moonshot-v1-8k' },
  { label: 'Qwen', base_url: 'https://dashscope.aliyuncs.com/compatible-mode', model: 'qwen-turbo' },
]

export default function ApiConfigSection() {
  const [configs, setConfigs] = useState([])
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [showKey, setShowKey] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [testResult, setTestResult] = useState(null)
  const [testing, setTesting] = useState(false)

  const api = window.electronAPI

  const loadConfigs = async () => {
    const data = await api.getApiConfigs()
    setConfigs(data)
  }

  useEffect(() => {
    loadConfigs()
  }, [])

  const openAdd = () => {
    setForm(EMPTY_FORM)
    setEditingId(null)
    setShowForm(true)
    setError('')
    setTestResult(null)
  }

  const openEdit = (config) => {
    setForm({
      name: config.name,
      base_url: config.base_url,
      api_key: config.api_key,
      model: config.model,
      system_prompt: config.system_prompt || '',
    })
    setEditingId(config.id)
    setShowForm(true)
    setError('')
    setTestResult(null)
  }

  const applyPreset = (preset) => {
    setForm((f) => ({
      ...f,
      name: f.name || preset.label,
      base_url: preset.base_url,
      model: preset.model,
    }))
  }

  const handleSave = async () => {
    if (!form.name.trim()) return setError('请填写配置名称')
    if (!form.base_url.trim()) return setError('请填写 Base URL')
    if (!form.api_key.trim()) return setError('请填写 API Key')
    if (!form.model.trim()) return setError('请填写模型名')

    setSaving(true)
    setError('')
    try {
      if (editingId) {
        await api.updateApiConfig(editingId, form)
      } else {
        await api.addApiConfig(form)
      }
      await loadConfigs()
      setShowForm(false)
    } catch (e) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('确认删除此配置？')) return
    await api.deleteApiConfig(id)
    await loadConfigs()
  }

  const handleSetActive = async (id) => {
    await api.setActiveConfig(id)
    await loadConfigs()
  }

  const handleTest = async () => {
    if (!form.base_url || !form.api_key || !form.model) {
      return setError('请先填写 Base URL、API Key 和模型名')
    }
    setTesting(true)
    setTestResult(null)
    try {
      // 去掉尾部斜杠和末尾 /v1，统一在这里补全
      const base = form.base_url.replace(/\/+$/, '').replace(/\/v1$/, '')
      const url = `${base}/v1/chat/completions`
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${form.api_key}`,
        },
        body: JSON.stringify({
          model: form.model,
          messages: [{ role: 'user', content: 'Reply with the single word: OK' }],
          max_tokens: 10,
        }),
        signal: AbortSignal.timeout(15_000),
      })
      if (!res.ok) {
        const txt = await res.text()
        setTestResult({ ok: false, msg: `HTTP ${res.status}: ${txt.slice(0, 200)}` })
      } else {
        const data = await res.json()
        const reply = data.choices?.[0]?.message?.content || '(empty)'
        setTestResult({ ok: true, msg: `✓ 连接成功，回复：${reply}` })
      }
    } catch (e) {
      setTestResult({ ok: false, msg: e.message })
    } finally {
      setTesting(false)
    }
  }

  return (
    <div className="section">
      <div className="section-header">
        <div>
          <h2 className="section-title">API 配置</h2>
          <p className="section-subtitle">添加 OpenAI 兼容的翻译 API，支持多配置切换</p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>
          + 新增配置
        </button>
      </div>

      {/* 配置列表 */}
      {configs.length === 0 ? (
        <div className="empty-state">
          <p>还没有 API 配置</p>
          <p className="empty-hint">点击「新增配置」添加 DeepSeek / OpenAI / Kimi 等任意兼容接口</p>
        </div>
      ) : (
        <div className="config-list">
          {configs.map((c) => (
            <div key={c.id} className={`config-card ${c.is_active ? 'active' : ''}`}>
              <div className="config-card-left">
                {c.is_active && <span className="badge-active">使用中</span>}
                <span className="config-name">{c.name}</span>
                <span className="config-model">{c.model}</span>
                <span className="config-url">{c.base_url}</span>
              </div>
              <div className="config-card-actions">
                {!c.is_active && (
                  <button className="btn btn-sm btn-ghost" onClick={() => handleSetActive(c.id)}>
                    启用
                  </button>
                )}
                <button className="btn btn-sm btn-ghost" onClick={() => openEdit(c)}>
                  编辑
                </button>
                <button
                  className="btn btn-sm btn-danger-ghost"
                  onClick={() => handleDelete(c.id)}
                >
                  删除
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 表单弹窗 */}
      {showForm && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowForm(false)}>
          <div className="modal">
            <div className="modal-header">
              <h3>{editingId ? '编辑 API 配置' : '新增 API 配置'}</h3>
              <button className="modal-close" onClick={() => setShowForm(false)}>✕</button>
            </div>

            <div className="modal-body">
              {/* 快捷预设 */}
              <div className="form-group">
                <label className="form-label">快捷预设</label>
                <div className="preset-list">
                  {PRESETS.map((p) => (
                    <button key={p.label} className="btn btn-sm btn-ghost" onClick={() => applyPreset(p)}>
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">配置名称 *</label>
                <input
                  className="form-input"
                  placeholder="例：DeepSeek"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Base URL *</label>
                <input
                  className="form-input"
                  placeholder="例：https://api.deepseek.com"
                  value={form.base_url}
                  onChange={(e) => setForm({ ...form, base_url: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">API Key *</label>
                <div className="input-with-btn">
                  <input
                    className="form-input"
                    type={showKey ? 'text' : 'password'}
                    placeholder="sk-..."
                    value={form.api_key}
                    onChange={(e) => setForm({ ...form, api_key: e.target.value })}
                  />
                  <button className="btn btn-sm btn-ghost" onClick={() => setShowKey(!showKey)}>
                    {showKey ? '隐藏' : '显示'}
                  </button>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">模型名 *</label>
                <input
                  className="form-input"
                  placeholder="例：deepseek-chat"
                  value={form.model}
                  onChange={(e) => setForm({ ...form, model: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">
                  自定义 System Prompt
                  <span className="form-hint">（留空使用默认翻译提示词）</span>
                </label>
                <textarea
                  className="form-textarea"
                  rows={4}
                  placeholder="你是一个专业翻译助手。将用户提供的{sourceLang}文本准确翻译为{targetLang}..."
                  value={form.system_prompt}
                  onChange={(e) => setForm({ ...form, system_prompt: e.target.value })}
                />
              </div>

              {error && <p className="form-error">{error}</p>}
              {testResult && (
                <p className={testResult.ok ? 'form-success' : 'form-error'}>{testResult.msg}</p>
              )}
            </div>

            <div className="modal-footer">
              <button className="btn btn-ghost" onClick={handleTest} disabled={testing}>
                {testing ? '测试中…' : '测试连接'}
              </button>
              <div className="modal-footer-right">
                <button className="btn btn-ghost" onClick={() => setShowForm(false)}>取消</button>
                <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
                  {saving ? '保存中…' : '保存'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
