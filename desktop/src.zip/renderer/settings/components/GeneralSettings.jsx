import React, { useState, useEffect } from 'react'

const LANG_OPTIONS = [
  { value: 'zh', label: '中文' },
  { value: 'en', label: '英文' },
  { value: 'ja', label: '日文' },
  { value: 'ko', label: '韩文' },
  { value: 'fr', label: '法文' },
  { value: 'de', label: '德文' },
]

// 常用快捷键预设
const HOTKEY_PRESETS = ['Alt+Z', 'Alt+X', 'Alt+Q', 'Ctrl+Alt+Z', 'Ctrl+Alt+X']

export default function GeneralSettings() {
  const [settings, setSettings] = useState(null)
  const [hookEnabled, setHookEnabled] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  const api = window.electronAPI

  useEffect(() => {
    api.getSettings().then(setSettings)
    api.isHookEnabled().then(setHookEnabled)

    // 监听主进程推送的 hook 状态变化（托盘菜单切换时）
    const unsub = api.onHookStatusChanged?.((enabled) => setHookEnabled(enabled))
    return () => unsub?.()
  }, [])

  const handleChange = (key, value) => {
    setSettings((s) => ({ ...s, [key]: value }))
  }

  const handleToggleHook = async () => {
    if (hookEnabled) {
      await api.disableHook()
      setHookEnabled(false)
    } else {
      await api.enableHook()
      setHookEnabled(true)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    for (const [key, value] of Object.entries(settings)) {
      await api.setSetting(key, value)
    }
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  if (!settings) return <div className="loading">加载设置中…</div>

  return (
    <div className="section">
      <div className="section-header">
        <div>
          <h2 className="section-title">通用设置</h2>
          <p className="section-subtitle">配置翻译语言偏好、划词取词和服务行为</p>
        </div>
      </div>

      <div className="settings-form">

        {/* ── 划词翻译 ─────────────────────────────────────────────────────── */}
        <div className="settings-group">
          <h3 className="settings-group-title">划词翻译</h3>

          <div className="form-group">
            <div className="hook-toggle-row">
              <div>
                <div className="form-label">全局划词翻译</div>
                <div className="form-hint" style={{ marginTop: 2 }}>
                  开启后，在任意应用选中文字并按快捷键，即可弹出翻译窗口
                </div>
              </div>
              <button
                className={`toggle-btn ${hookEnabled ? 'toggle-btn-on' : ''}`}
                onClick={handleToggleHook}
              >
                <span className="toggle-knob" />
              </button>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">
              触发快捷键
              <span className="form-hint">（修改后立即生效）</span>
            </label>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <input
                className="form-input form-input-sm"
                type="text"
                value={settings.hotkey || 'Alt+Z'}
                onChange={(e) => handleChange('hotkey', e.target.value)}
                style={{ width: 130 }}
                placeholder="如 Alt+Z"
              />
              <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                {HOTKEY_PRESETS.map((k) => (
                  <button
                    key={k}
                    className="btn btn-secondary btn-xs"
                    onClick={() => handleChange('hotkey', k)}
                    style={{
                      fontFamily: 'monospace',
                      fontSize: 11,
                      padding: '2px 8px',
                      background: settings.hotkey === k ? '#eef2ff' : undefined,
                      borderColor: settings.hotkey === k ? '#6366f1' : undefined,
                      color: settings.hotkey === k ? '#6366f1' : undefined,
                    }}
                  >
                    {k}
                  </button>
                ))}
              </div>
            </div>
            <p className="form-hint" style={{ marginTop: 6 }}>
              使用方法：先在任意应用中<strong>选中文字</strong>，再按快捷键触发翻译弹窗
            </p>
          </div>
        </div>

        {/* ── 翻译语言 ─────────────────────────────────────────────────────── */}
        <div className="settings-group">
          <h3 className="settings-group-title">翻译语言</h3>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">源语言</label>
              <select
                className="form-select"
                value={settings.source_lang || 'en'}
                onChange={(e) => handleChange('source_lang', e.target.value)}
              >
                {LANG_OPTIONS.map((l) => (
                  <option key={l.value} value={l.value}>{l.label}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">目标语言</label>
              <select
                className="form-select"
                value={settings.target_lang || 'zh'}
                onChange={(e) => handleChange('target_lang', e.target.value)}
              >
                {LANG_OPTIONS.map((l) => (
                  <option key={l.value} value={l.value}>{l.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label className="form-toggle">
              <input
                type="checkbox"
                checked={settings.auto_detect_lang === '1'}
                onChange={(e) => handleChange('auto_detect_lang', e.target.checked ? '1' : '0')}
              />
              <span>自动检测源语言</span>
            </label>
          </div>
        </div>

        {/* ── 服务设置 ─────────────────────────────────────────────────────── */}
        <div className="settings-group">
          <h3 className="settings-group-title">服务设置</h3>

          <div className="form-group">
            <label className="form-label">
              HTTP 端口
              <span className="form-hint">（浏览器插件通信端口，修改后需重启应用）</span>
            </label>
            <input
              className="form-input form-input-sm"
              type="number"
              min="1024"
              max="65535"
              value={settings.port || '27463'}
              onChange={(e) => handleChange('port', e.target.value)}
            />
          </div>
        </div>

        <div className="form-actions">
          <button className="btn btn-primary" onClick={handleSave} disabled={saving}>
            {saving ? '保存中…' : saved ? '✓ 已保存' : '保存设置'}
          </button>
        </div>
      </div>
    </div>
  )
}
