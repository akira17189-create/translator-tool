import React, { useState, useEffect, useCallback } from 'react'
import ApiConfigSection from './components/ApiConfigSection.jsx'
import GeneralSettings from './components/GeneralSettings.jsx'

// ── Design tokens ─────────────────────────────────────────────────────────────
const C = {
  cream:'#F3F0EE', creamLifted:'#FCFBFA', ink:'#141413',
  white:'#FFFFFF', slate:'#696969', orange:'#F37338', signal:'#CF4500',
  inkBorder10:'rgba(20,20,19,0.10)',
}
const FONT = "'Sofia Sans', Arial, sans-serif"
const SHADOW_LIFT = '0 24px 48px rgba(0,0,0,0.08), 0 8px 16px rgba(0,0,0,0.04)'

const NAV = [
  { id: 'api',     label: 'API 配置' },
  { id: 'general', label: '通用设置' },
]

const s = {
  shell: {
    width:'100%', height:'100%', background:C.cream, fontFamily:FONT, color:C.ink,
    display:'flex', gap:16, padding:16, boxSizing:'border-box', overflow:'hidden',
  },
  sidebar: {
    width:200, background:C.white, borderRadius:32, boxShadow:SHADOW_LIFT,
    padding:'20px 14px 16px', display:'flex', flexDirection:'column', flexShrink:0,
  },
  brand: { display:'flex', alignItems:'center', gap:8, padding:'4px 8px 18px' },
  brandMark: { display:'flex', alignItems:'center' },
  brandDot: { width:16, height:16, borderRadius:'50%', display:'inline-block' },
  brandName: { fontSize:14, fontWeight:500, letterSpacing:'-0.02em', color:C.ink, lineHeight:1.1, whiteSpace:'nowrap' },
  brandSub: { fontSize:10, fontWeight:700, letterSpacing:'0.04em', textTransform:'uppercase', color:C.slate, marginTop:2 },
  navList: { listStyle:'none', padding:0, margin:0, display:'flex', flexDirection:'column', gap:4, flex:1 },
  navItem: {
    width:'100%', textAlign:'left', border:'none', fontFamily:FONT,
    fontSize:14, letterSpacing:'-0.02em', padding:'10px 16px', borderRadius:999,
    cursor:'pointer', transition:'background 0.15s ease, color 0.15s ease',
  },
  statusFoot: {
    display:'flex', alignItems:'center', gap:7, padding:'12px 16px 2px',
    fontSize:11, fontWeight:450, letterSpacing:'-0.01em', color:C.slate,
    borderTop:`1px solid ${C.inkBorder10}`, marginTop:8,
  },
  main: { flex:1, display:'flex', flexDirection:'column', gap:10, minWidth:0 },
  card: {
    flex:1, background:C.cream, border:`1px solid ${C.inkBorder10}`,
    borderRadius:32, overflow:'auto', minHeight:0,
  },
  versionBar: {
    display:'flex', alignItems:'center', gap:10, padding:'0 20px',
    fontSize:11, fontWeight:450, letterSpacing:'-0.01em', color:C.slate, flexShrink:0,
  },
}

export default function App() {
  const [tab, setTab]               = useState('api')
  const [serverStatus, setStatus]   = useState('checking')

  useEffect(() => {
    const check = async () => {
      try {
        const res  = await fetch('http://127.0.0.1:27463/status', { signal: AbortSignal.timeout(2000) })
        const data = await res.json()
        setStatus(data.running ? 'online' : 'offline')
      } catch { setStatus('offline') }
    }
    check()
    const interval = setInterval(check, 10_000)
    return () => clearInterval(interval)
  }, [])

  const statusColor = serverStatus === 'online' ? C.orange : (serverStatus === 'offline' ? C.signal : C.slate)

  return (
    <div style={s.shell}>
      {/* Sidebar */}
      <aside style={s.sidebar}>
        <div style={s.brand}>
          <div style={s.brandMark}>
            <span style={{ ...s.brandDot, background: C.signal }} />
            <span style={{ ...s.brandDot, background: C.orange, marginLeft: -8 }} />
          </div>
          <div>
            <div style={s.brandName}>翻译工具</div>
            <div style={s.brandSub}>Settings</div>
          </div>
        </div>

        <ul style={s.navList}>
          {NAV.map(n => {
            const active = tab === n.id
            return (
              <li key={n.id}>
                <button type="button" onClick={() => setTab(n.id)}
                  style={{ ...s.navItem, background: active ? C.ink : 'transparent', color: active ? C.cream : C.ink, fontWeight: active ? 500 : 450 }}>
                  {n.label}
                </button>
              </li>
            )
          })}
        </ul>

        <div style={s.statusFoot}>
          <span style={{ width:7, height:7, borderRadius:'50%', background:statusColor, display:'inline-block', flexShrink:0 }} />
          <span>
            {serverStatus === 'online' ? '服务运行中 · :27463'
              : serverStatus === 'offline' ? '服务离线'
              : '检测中…'}
          </span>
        </div>
      </aside>

      {/* Main */}
      <main style={s.main}>
        <div style={s.card}>
          {tab === 'api'     && <ApiConfigSection />}
          {tab === 'general' && <GeneralSettings />}
        </div>
        <div style={s.versionBar}>
          <span>翻译工具 · Settings</span>
          <span style={{ flex:1 }} />
        </div>
      </main>
    </div>
  )
}
