import { app, BrowserWindow, ipcMain, shell, screen } from 'electron'
import { join } from 'path'
import {
  initDatabase,
  getApiConfigs, addApiConfig, updateApiConfig, deleteApiConfig, setActiveConfig,
  getSettings, setSetting,
  addWordToWordbook, deleteWordFromWordbook, getWordbook,
  getGlossary, addGlossaryTerm, updateGlossaryTerm, deleteGlossaryTerm,
} from './database.js'
import { startServer, stopServer } from './server.js'
import { setupTray } from './tray.js'
import { initDictionary, lookupWord } from './dictionary.js'
import { initGlobalHook, enableHook, disableHook, isHookEnabled, updateHotkey, destroyGlobalHook } from './globalHook.js'
import { translate } from './translate.js'

let mainWindow = null
let popupWindow = null
let popupPinned = false

// ─── 设置窗口 ─────────────────────────────────────────────────────────────────

function createSettingsWindow() {
  const win = new BrowserWindow({
    width: 900,
    height: 680,
    minWidth: 720,
    minHeight: 500,
    title: '翻译工具 · 设置',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  if (process.env['ELECTRON_RENDERER_URL']) {
    win.loadURL(process.env['ELECTRON_RENDERER_URL'] + '/settings/index.html')
  } else {
    win.loadFile(join(__dirname, '../renderer/settings/index.html'))
  }

  win.on('close', (e) => {
    if (!app.isQuiting) {
      e.preventDefault()
      win.hide()
    }
  })

  return win
}

// ─── 翻译弹窗 ─────────────────────────────────────────────────────────────────

function createPopupWindow() {
  const win = new BrowserWindow({
    width: 360,
    height: 260,
    minWidth: 280,
    maxWidth: 480,
    maxHeight: 520,
    frame: false,
    transparent: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    resizable: false,
    movable: true,
    show: false,
    title: '翻译',
    backgroundColor: '#ffffff',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  if (process.env['ELECTRON_RENDERER_URL']) {
    win.loadURL(process.env['ELECTRON_RENDERER_URL'] + '/popup/index.html')
  } else {
    win.loadFile(join(__dirname, '../renderer/popup/index.html'))
  }

  win.on('blur', () => {
    if (!popupPinned) win.hide()
  })

  return win
}

/**
 * 在鼠标附近显示翻译弹窗
 */
async function showPopup({ text, x, y }) {
  if (!popupWindow || popupWindow.isDestroyed()) {
    popupWindow = createPopupWindow()
  }

  popupPinned = false

  // 发送加载中状态
  popupWindow.webContents.send('popup:loading', { text })

  // 计算弹窗位置（在鼠标右下角，避免超出屏幕）
  const display = screen.getDisplayNearestPoint({ x, y })
  const { bounds } = display
  const winW = 360
  const winH = 260

  let posX = x + 16
  let posY = y + 16
  if (posX + winW > bounds.x + bounds.width)  posX = x - winW - 8
  if (posY + winH > bounds.y + bounds.height) posY = y - winH - 8
  posX = Math.max(bounds.x + 4, posX)
  posY = Math.max(bounds.y + 4, posY)

  popupWindow.setPosition(Math.round(posX), Math.round(posY))
  popupWindow.setSize(winW, winH)
  popupWindow.showInactive()
  popupWindow.focus()

  // 判断是否是单词（用于决定是否查词典）
  const trimmed = text.trim()
  const isSingleWord = trimmed.split(/\s+/).length <= 2 && /^[a-zA-Z''-]+$/.test(trimmed.replace(/\s+/g, ''))

  // 并发执行：词典查询 + AI 翻译
  const [dictResult, transResult] = await Promise.allSettled([
    isSingleWord ? Promise.resolve(lookupWord(trimmed)) : Promise.resolve(null),
    translate({ text: trimmed, mode: isSingleWord ? 'word' : 'sentence' }),
  ])

  const dictData  = dictResult.status === 'fulfilled'  ? dictResult.value  : null
  const transData = transResult.status === 'fulfilled' ? transResult.value : { translation: '', offline: true }

  if (!popupWindow || popupWindow.isDestroyed()) return

  const payload = {
    text: trimmed,
    isSingleWord,
    dict: dictData,
    translation: transData.translation,
    engine: transData.engine,
    offline: transData.offline,
    error: transData.error,
  }

  popupWindow.webContents.send('popup:data', payload)

  // 根据内容自动调整高度
  const hasDict = dictData?.found && dictData?.definitions?.length > 0
  const newH = hasDict ? Math.min(420, winH + dictData.definitions.length * 22 + 80) : winH
  popupWindow.setSize(winW, newH)
}

// ─── IPC Handlers ─────────────────────────────────────────────────────────────

function registerIpcHandlers() {
  // API 配置
  ipcMain.handle('db:getApiConfigs', () => getApiConfigs())
  ipcMain.handle('db:addApiConfig', (_, config) => addApiConfig(config))
  ipcMain.handle('db:updateApiConfig', (_, id, config) => updateApiConfig(id, config))
  ipcMain.handle('db:deleteApiConfig', (_, id) => deleteApiConfig(id))
  ipcMain.handle('db:setActiveConfig', (_, id) => setActiveConfig(id))

  // 设置
  ipcMain.handle('db:getSettings', () => getSettings())
  ipcMain.handle('db:setSetting', (_, key, value) => {
    setSetting(key, String(value))
    if (key === 'hotkey') updateHotkey(value)
  })

  // 生词本
  ipcMain.handle('db:getWordbook', () => getWordbook())
  ipcMain.handle('db:addWord', (_, entry) => addWordToWordbook(entry))
  ipcMain.handle('db:deleteWord', (_, id) => deleteWordFromWordbook(id))

  // 术语表
  ipcMain.handle('db:getGlossary', () => getGlossary())
  ipcMain.handle('db:addGlossaryTerm', (_, term) => addGlossaryTerm(term))
  ipcMain.handle('db:updateGlossaryTerm', (_, id, term) => updateGlossaryTerm(id, term))
  ipcMain.handle('db:deleteGlossaryTerm', (_, id) => deleteGlossaryTerm(id))

  // 全局 Hook 开关
  ipcMain.handle('hook:isEnabled', () => isHookEnabled())
  ipcMain.handle('hook:enable', () => {
    enableHook()
    setSetting('hook_enabled', '1')
    mainWindow?.webContents.send('hook:statusChanged', true)
  })
  ipcMain.handle('hook:disable', () => {
    disableHook()
    setSetting('hook_enabled', '0')
    mainWindow?.webContents.send('hook:statusChanged', false)
  })

  // 弹窗控制
  ipcMain.handle('popup:close', () => { popupWindow?.hide() })
  ipcMain.handle('popup:pin', (_, pinned) => { popupPinned = pinned })

  // 词典直查
  ipcMain.handle('dict:lookup', (_, word) => lookupWord(word))

  // 翻译直调
  ipcMain.handle('translate:run', (_, opts) => translate(opts))

  // 其他
  ipcMain.handle('shell:openExternal', (_, url) => shell.openExternal(url))
}

// ─── App Lifecycle ────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  initDatabase()
  initDictionary()
  registerIpcHandlers()
  startServer()

  mainWindow  = createSettingsWindow()
  popupWindow = createPopupWindow()

  const settings   = getSettings()
  const hotkey     = settings.hotkey || 'Alt+Z'
  const hookActive = settings.hook_enabled === '1'

  initGlobalHook({
    hotkey,
    onSelection: (text, x, y) => showPopup({ text, x, y }),
  })

  if (hookActive) enableHook()

  setupTray(app, mainWindow, {
    isHookEnabled,
    enableHook: () => {
      enableHook()
      setSetting('hook_enabled', '1')
      mainWindow?.webContents.send('hook:statusChanged', true)
    },
    disableHook: () => {
      disableHook()
      setSetting('hook_enabled', '0')
      mainWindow?.webContents.send('hook:statusChanged', false)
    },
  })

  app.on('activate', () => { if (mainWindow) mainWindow.show() })
})

app.on('before-quit', () => {
  app.isQuiting = true
  destroyGlobalHook()
  stopServer()
})

app.on('window-all-closed', () => {
  // 托盘保持运行
})
