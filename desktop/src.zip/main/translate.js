import { getActiveApiConfig, getGlossary, getSetting } from './database.js'

const DEFAULT_SYSTEM_PROMPT = `你是一个专业翻译助手。将用户提供的{sourceLang}文本准确翻译为{targetLang}。
只输出译文，不要解释，不要加引号，不要添加任何额外内容。`

/**
 * 构建注入了术语表的 system prompt
 */
function buildSystemPrompt(config, sourceLang, targetLang) {
  let base = config.system_prompt?.trim() || DEFAULT_SYSTEM_PROMPT
  base = base.replace('{sourceLang}', sourceLang).replace('{targetLang}', targetLang)

  const glossary = getGlossary()
  if (glossary.length > 0) {
    const lines = glossary.map((t) => `${t.source_term} → ${t.target_term}`)
    base += `\n\n以下术语表必须严格遵守（不得更改这些词的译法）：\n${lines.join('\n')}`
  }

  return base
}

/**
 * 主翻译函数
 * @param {Object} opts
 * @param {string} opts.text - 要翻译的文本
 * @param {string} [opts.sourceLang='en'] - 源语言
 * @param {string} [opts.targetLang='zh'] - 目标语言
 * @param {string} [opts.context=''] - 可选上下文
 * @param {'word'|'sentence'|'paragraph'} [opts.mode='sentence'] - 翻译模式
 * @returns {Promise<{translation: string, engine: string, offline: boolean}>}
 */
export async function translate({ text, sourceLang, targetLang, context = '', mode = 'sentence' }) {
  const resolvedSource = sourceLang || getSetting('source_lang', 'en')
  const resolvedTarget = targetLang || getSetting('target_lang', 'zh')

  const config = getActiveApiConfig()

  if (!config) {
    return {
      translation: '',
      engine: null,
      offline: true,
      error: '未配置翻译 API，请在设置页添加 API 配置并激活。',
    }
  }

  const systemPrompt = buildSystemPrompt(config, resolvedSource, resolvedTarget)

  let userPrompt = text
  if (context && context !== text) {
    userPrompt = `上下文：${context}\n\n请翻译以下${mode === 'word' ? '单词' : '文本'}：${text}`
  }

  try {
    const baseUrl = config.base_url.replace(/\/$/, '')
    const url = `${baseUrl}/v1/chat/completions`

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.api_key}`,
      },
      body: JSON.stringify({
        model: config.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 2048,
      }),
      signal: AbortSignal.timeout(30_000), // 30s 超时
    })

    if (!response.ok) {
      const errText = await response.text().catch(() => '')
      throw new Error(`API 错误 ${response.status}: ${errText}`)
    }

    const data = await response.json()
    const translation = data.choices?.[0]?.message?.content?.trim() || ''

    return {
      translation,
      engine: config.name,
      offline: false,
    }
  } catch (err) {
    console.error('[translate] API call failed:', err.message)
    return {
      translation: '',
      engine: config.name,
      offline: true,
      error: err.message,
    }
  }
}
