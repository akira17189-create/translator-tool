/**
 * globalHook.js — 全局划词监听
 *
 * 工作流程（两种方式）：
 *
 * 方式一：快捷键（推荐，兼容性最好）
 *   1. 用户在任意应用中选中文字
 *   2. 按下配置的快捷键（默认 Alt+Z）
 *   3. 应用模拟 Ctrl+C 将选中内容复制到剪贴板
 *   4. 读取剪贴板 → 翻译 → 显示弹窗
 *
 * 方式二：鼠标松开自动检测（uiohook-napi）
 *   1. uiohook-napi 监听全局 mouseup 事件
 *   2. 松开左键后模拟 Ctrl+C
 *   3. 若剪贴板内容变化 → 翻译 → 显示弹窗
 *   注：此方式仅在 Windows 上开启，macOS/Linux 暂不支持
 */

import { clipboard, globalShortcut, screen } from 'electron'
import { uIOhook } from 'uiohook-napi'
import { execFile } from 'child_process'

// ─── State ────────────────────────────────────────────────────────────────────

let isEnabled = false
let onSelectionCallback = null  // (text: string, x: number, y: number) => void
let currentHotkey = 'Alt+Z'
let lastKnownClipboard = ''
let pendingMouseTranslate = false  // 防止并发触发

// ─── Main API ─────────────────────────────────────────────────────────────────

/**
 * 初始化全局 Hook
 * @param {{ onSelection: Function, hotkey?: string }} opts
 */
export function initGlobalHook({ onSelection, hotkey = 'Alt+Z' }) {
  onSelectionCallback = onSelection
  currentHotkey = hotkey
  lastKnownClipboard = clipboard.readText()

  // 注册快捷键
  registerHotkey(hotkey)

  // Windows 上启动 uiohook 鼠标监听
  if (process.platform === 'win32') {
    setupMouseHook()
  }

  console.log('[globalHook] Initialized. Hotkey:', hotkey)
}

export function enableHook() {
  isEnabled = true
  console.log('[globalHook] Enabled')
}

export function disableHook() {
  isEnabled = false
  console.log('[globalHook] Disabled')
}

export function isHookEnabled() {
  return isEnabled
}

/**
 * 更新快捷键配置
 */
export function updateHotkey(newHotkey) {
  if (currentHotkey) {
    try { globalShortcut.unregister(currentHotkey) } catch {}
  }
  currentHotkey = newHotkey
  registerHotkey(newHotkey)
}

/**
 * 清理：应用退出时调用
 */
export function destroyGlobalHook() {
  if (currentHotkey) {
    try { globalShortcut.unregister(currentHotkey) } catch {}
  }
  try { uIOhook.stop() } catch {}
}

// ─── 快捷键处理 ───────────────────────────────────────────────────────────────

function registerHotkey(hotkey) {
  if (!hotkey) return
  try {
    const ok = globalShortcut.register(hotkey, handleHotkeyTriggered)
    if (!ok) {
      console.warn('[globalHook] Hotkey registration failed (may be in use):', hotkey)
    }
  } catch (err) {
    console.error('[globalHook] Failed to register hotkey:', err.message)
  }
}

async function handleHotkeyTriggered() {
  if (!isEnabled) return

  // 先模拟 Ctrl+C，把选中文字复制到剪贴板
  const prevClip = clipboard.readText()
  await simulateCtrlC()
  await sleep(200)

  const newText = clipboard.readText().trim()

  if (!newText) return

  // 避免重复翻译相同内容（快速连按时）
  if (newText === lastKnownClipboard && newText === prevClip) return

  lastKnownClipboard = newText
  const pos = screen.getCursorScreenPoint()
  onSelectionCallback?.(newText, pos.x, pos.y)
}

// ─── 鼠标 Hook（Windows only）────────────────────────────────────────────────

function setupMouseHook() {
  let mouseUpX = 0
  let mouseUpY = 0

  uIOhook.on('mouseup', async (e) => {
    if (!isEnabled || e.button !== 1) return  // 只处理左键
    if (pendingMouseTranslate) return          // 防并发

    mouseUpX = e.x
    mouseUpY = e.y

    // 等待用户完成选择操作
    await sleep(150)

    pendingMouseTranslate = true
    try {
      const prevClip = clipboard.readText()
      await simulateCtrlC()
      await sleep(200)

      const newText = clipboard.readText().trim()

      // 只有剪贴板确实变化了才处理（说明用户选中了新内容）
      if (!newText || newText === prevClip) return

      // 如果和上一次相同，跳过（避免重复弹窗）
      if (newText === lastKnownClipboard) return

      // 过滤：太长的不算"划词"（超过 500 字符视为粘贴操作）
      if (newText.length > 500) return

      lastKnownClipboard = newText
      onSelectionCallback?.(newText, mouseUpX, mouseUpY)
    } finally {
      pendingMouseTranslate = false
    }
  })

  uIOhook.start()
}

// ─── 工具函数 ─────────────────────────────────────────────────────────────────

/**
 * 模拟 Ctrl+C（Windows 专用）
 * 使用 PowerShell 的 SendKeys，约 100-250ms 延迟
 */
function simulateCtrlC() {
  if (process.platform !== 'win32') {
    return Promise.resolve()
  }
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      [
        '-NoLogo',
        '-NoProfile',
        '-NonInteractive',
        '-WindowStyle', 'Hidden',
        '-Command',
        'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait("^c")',
      ],
      { windowsHide: true, timeout: 3000 },
      () => resolve()  // 无论成功失败都 resolve，由调用方检查剪贴板
    )
  })
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
